// Empty background script for manifest v3
